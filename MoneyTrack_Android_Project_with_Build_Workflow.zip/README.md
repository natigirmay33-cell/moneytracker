# MoneyTrack Android app project

This is an Android Studio project for a basic offline personal income/expense tracker.

## Features
- Choose a date and add income or expenses in ETB
- Categories and descriptions
- Monthly income, expense, remaining-balance summary
- Category breakdown and all-transaction list
- Records stored locally on the phone

## Build an installable APK
1. Install Android Studio on a computer.
2. Open this folder as a project.
3. Allow Gradle to sync and download Android build tools.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK will be in `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer the APK to your Samsung Galaxy A16 and open it. If Android asks, allow installation from that file app.

## Important
This chat cannot directly install an app on your phone, and this project ZIP is not itself an APK. Building requires Android Studio/Android SDK. The app keeps its data locally; uninstalling the app or clearing its data can erase records. Add backups/export before relying on it for important financial records.
