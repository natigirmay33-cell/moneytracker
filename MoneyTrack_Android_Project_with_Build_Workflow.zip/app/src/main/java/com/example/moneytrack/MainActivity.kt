package com.example.moneytrack

import android.app.Activity
import android.app.DatePickerDialog
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("moneytrack", MODE_PRIVATE) }
    private val items = mutableListOf<Tx>()
    private var selectedDate = Calendar.getInstance()
    private lateinit var root: LinearLayout
    private lateinit var summary: TextView
    private lateinit var list: LinearLayout
    private val green = Color.rgb(0, 145, 92)
    private val red = Color.rgb(215, 55, 70)
    private val navy = Color.rgb(20, 37, 58)
    data class Tx(val id: Long, val date: String, val type: String, val category: String, val description: String, val amount: Double)

    private fun dateKey(c: Calendar = selectedDate): String =
        "%04d-%02d-%02d".format(c.get(Calendar.YEAR), c.get(Calendar.MONTH)+1, c.get(Calendar.DAY_OF_MONTH))
    private fun money(n: Double) = "%,.2f ETB".format(n)
    private fun monthKey(): String = dateKey().substring(0,7)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        load()
        render()
    }

    private fun load() {
        items.clear()
        val arr = try { JSONArray(prefs.getString("transactions", "[]")) } catch (_: Exception) { JSONArray() }
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            items.add(Tx(o.optLong("id"), o.optString("date"), o.optString("type"), o.optString("category"), o.optString("description"), o.optDouble("amount")))
        }
    }
    private fun save() {
        val arr = JSONArray()
        items.forEach { t -> arr.put(JSONObject().put("id",t.id).put("date",t.date).put("type",t.type).put("category",t.category).put("description",t.description).put("amount",t.amount)) }
        prefs.edit().putString("transactions",arr.toString()).apply()
    }
    private fun text(s: String, size: Float=16f, color: Int=navy, bold: Boolean=false): TextView =
        TextView(this).apply { text=s; textSize=size; setTextColor(color); if(bold) setTypeface(null,1); setPadding(4,8,4,8) }
    private fun button(s: String, action: () -> Unit) = Button(this).apply { text=s; setOnClickListener { action() } }
    private fun field(hintText: String) = EditText(this).apply { hint=hintText; textSize=16f; setSingleLine(true); setPadding(18,10,18,10) }
    private fun section(title: String) {
        root.addView(text(title,20f,navy,true))
    }

    private fun render() {
        root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(Color.rgb(246,248,251)); setPadding(18,12,18,12) }
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)
        root.addView(text("💰 MoneyTrack",26f,green,true))
        root.addView(text("Your daily income and expenses",14f,Color.DKGRAY))
        root.addView(button("📅  Selected date: ${dateKey()}  —  Change date") { chooseDate() })
        val monthItems = items.filter { it.date.startsWith(monthKey()) }
        val income = monthItems.filter { it.type=="Income" }.sumOf { it.amount }
        val expenses = monthItems.filter { it.type=="Expense" }.sumOf { it.amount }
        val bal = income-expenses
        summary = text("MONTHLY SUMMARY\nIncome   ${money(income)}\nExpenses  ${money(expenses)}\nMoney left  ${money(bal)}",17f,Color.WHITE,true)
        summary.setBackgroundColor(navy); summary.setPadding(16,18,16,18)
        root.addView(summary)
        root.addView(button("＋  Add transaction") { addTransaction() })
        section("Transactions on ${dateKey()}")
        list = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        root.addView(list)
        val dayItems = items.filter { it.date==dateKey() }.sortedByDescending { it.id }
        if(dayItems.isEmpty()) list.addView(text("No transactions yet. Tap Add transaction to begin.",14f,Color.GRAY))
        dayItems.forEach { t ->
            val row = LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER_VERTICAL; setPadding(4,8,4,8) }
            val details = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
            details.addView(text("${t.description} · ${t.category}",16f,navy,true))
            details.addView(text("${t.type} · ${t.date}",12f,Color.GRAY))
            row.addView(details, LinearLayout.LayoutParams(0,-2,1f))
            row.addView(text((if(t.type=="Income") "+" else "−")+money(t.amount),14f,if(t.type=="Income") green else red,true))
            row.addView(button("×") {
                items.removeAll { it.id==t.id }; save(); render()
            })
            list.addView(row)
            val line=View(this).apply { setBackgroundColor(Color.LTGRAY) }
            list.addView(line, LinearLayout.LayoutParams(-1,1))
        }
        root.addView(button("📊  Monthly totals & all records") { showMonthlyReport() })
        root.addView(button("🗂  All transactions") { showAll() })
        root.addView(text("Your records are stored locally on this phone.",12f,Color.GRAY))
    }

    private fun chooseDate() {
        DatePickerDialog(this,{ _, y,m,d ->
            selectedDate.set(y,m,d); render()
        },selectedDate.get(Calendar.YEAR),selectedDate.get(Calendar.MONTH),selectedDate.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun addTransaction() {
        val box = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(20,8,20,0) }
        val type = Spinner(this)
        type.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("Expense","Income"))
        val category = Spinner(this)
        val cats = listOf("Food","Transport","Shopping","Bills","Rent","Health","Education","Salary","Business","Gift","Other")
        category.adapter = ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,cats)
        val desc = field("Description (e.g. lunch, salary)")
        val amount = field("Amount in ETB").apply { inputType=android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL }
        box.addView(text("Type")); box.addView(type)
        box.addView(text("Category")); box.addView(category)
        box.addView(text("Description")); box.addView(desc)
        box.addView(text("Amount (ETB)")); box.addView(amount)
        AlertDialogBuilder.show(this,"Add transaction",box,{
            val value = amount.text.toString().toDoubleOrNull()
            if(desc.text.toString().trim().isEmpty() || value==null || value<=0) {
                Toast.makeText(this,"Enter a description and a positive amount.",Toast.LENGTH_LONG).show()
            } else {
                items.add(Tx(System.currentTimeMillis(),dateKey(),type.selectedItem.toString(),category.selectedItem.toString(),desc.text.toString().trim(),value))
                save(); render()
            }
        })
    }

    private fun showMonthlyReport() {
        val month = monthKey()
        val a = items.filter { it.date.startsWith(month) }
        val inc = a.filter { it.type=="Income" }.sumOf { it.amount }
        val exp = a.filter { it.type=="Expense" }.sumOf { it.amount }
        val byCat = a.filter { it.type=="Expense" }.groupBy { it.category }.mapValues { e -> e.value.sumOf { it.amount } }.toList().sortedByDescending { it.second }
        val msg = buildString {
            append("Month: $month\n\nIncome: ${money(inc)}\nExpenses: ${money(exp)}\nMoney left: ${money(inc-exp)}\nTransactions: ${a.size}\n\nExpenses by category:\n")
            if(byCat.isEmpty()) append("No expenses recorded")
            else byCat.forEach { append("${it.first}: ${money(it.second)}\n") }
        }
        android.app.AlertDialog.Builder(this).setTitle("Monthly report").setMessage(msg).setPositiveButton("OK",null).show()
    }

    private fun showAll() {
        val msg = items.sortedByDescending { it.date }.joinToString("\n\n") {
            "${it.date} · ${it.type}\n${it.description} (${it.category})\n${if(it.type=="Income") "+" else "−"}${money(it.amount)}"
        }.ifBlank { "No transactions recorded yet." }
        android.app.AlertDialog.Builder(this).setTitle("All transactions").setMessage(msg).setPositiveButton("OK",null).show()
    }
}
private object AlertDialogBuilder {
    fun show(activity: Activity, title: String, view: View, save: () -> Unit) {
        android.app.AlertDialog.Builder(activity).setTitle(title).setView(view)
            .setPositiveButton("Save") { _,_ -> save() }
            .setNegativeButton("Cancel",null).show()
    }
}
